"""
main.py
--------
Command-line entry point for the RAG Document Question Answering system.

Usage:
    # Build the vector store once from PDFs/text files in data/raw
    python main.py --build --source folder --path data/raw

    # Build the vector store from a Hugging Face dataset instead
    python main.py --build --source hf --dataset squad --max_docs 200

    # Ask a question (reuses the persisted Chroma DB)
    python main.py --ask "What is the main idea of the document?"
"""

import argparse

from src.data_loader import load_folder, load_huggingface_dataset
from src.chunker import chunk_documents
from src.vector_store import build_vector_store, load_vector_store
from src.rag import answer_question


def build_index(args):
    print(f"[1/4] Loading documents from source: {args.source}")
    if args.source == "folder":
        documents = load_folder(args.path)
    elif args.source == "hf":
        documents = load_huggingface_dataset(
            dataset_name=args.dataset,
            max_docs=args.max_docs,
        )
    else:
        raise ValueError("source must be 'folder' or 'hf'")

    print(f"    Loaded {len(documents)} document(s)")

    print("[2/4] Chunking text...")
    chunks = chunk_documents(documents, chunk_size=args.chunk_size, chunk_overlap=args.chunk_overlap)
    print(f"    Produced {len(chunks)} chunk(s)")

    print("[3/4] Creating embeddings + building vector store...")
    build_vector_store(chunks, persist_directory=args.persist_dir)

    print(f"[4/4] Done. Vector store saved to '{args.persist_dir}/'")


def ask(args):
    vector_store = load_vector_store(persist_directory=args.persist_dir)
    result = answer_question(vector_store, args.ask, k=args.k, model_name=args.model)

    print("\nQuestion:", result["question"])
    print("\nAnswer:", result["answer"])
    print("\nSources used:")
    for s in result["sources"]:
        print("  -", s)


def main():
    parser = argparse.ArgumentParser(description="RAG Document Question Answering")
    parser.add_argument("--build", action="store_true", help="Build the vector store index")
    parser.add_argument("--ask", type=str, help="Ask a question against the existing index")

    parser.add_argument("--source", choices=["folder", "hf"], default="folder")
    parser.add_argument("--path", type=str, default="data/raw", help="Folder of PDFs/txt files")
    parser.add_argument("--dataset", type=str, default="squad", help="Hugging Face dataset name")
    parser.add_argument("--max_docs", type=int, default=200)

    parser.add_argument("--chunk_size", type=int, default=500)
    parser.add_argument("--chunk_overlap", type=int, default=50)
    parser.add_argument("--persist_dir", type=str, default="chroma_db")

    parser.add_argument("--k", type=int, default=4, help="Number of chunks to retrieve")
    parser.add_argument("--model", type=str, default="llama3", help="Ollama model name")

    args = parser.parse_args()

    if args.build:
        build_index(args)
    elif args.ask:
        ask(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
