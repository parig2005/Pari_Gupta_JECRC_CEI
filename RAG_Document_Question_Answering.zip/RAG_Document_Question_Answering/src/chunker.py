"""
chunker.py
-----------
Splits raw document text into smaller overlapping chunks.

Why chunk?
    Retrieval works best on small, semantically focused pieces of text.
    A whole PDF is too large and noisy to embed as a single vector;
    a well-sized chunk (a few sentences to a short paragraph) retrieves
    much more precisely.

Uses LangChain's RecursiveCharacterTextSplitter, which tries to split
on paragraph breaks first, then sentences, then words -- only falling
back to a hard character cut if nothing else fits.
"""

from typing import List, Dict
from langchain_text_splitters import RecursiveCharacterTextSplitter


def chunk_documents(
    documents: List[Dict],
    chunk_size: int = 500,
    chunk_overlap: int = 50,
) -> List[Dict]:
    """
    Split a list of {"source", "text"} documents into chunks.

    Args:
        documents: output of data_loader.py load_* functions
        chunk_size: max characters per chunk
        chunk_overlap: characters shared between consecutive chunks,
                       so context isn't lost at chunk boundaries

    Returns:
        List of {"source", "chunk_id", "text"} dicts, one per chunk.
    """
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n\n", "\n", ". ", " ", ""],
    )

    chunks = []
    for doc in documents:
        pieces = splitter.split_text(doc["text"])
        for i, piece in enumerate(pieces):
            chunks.append(
                {
                    "source": doc["source"],
                    "chunk_id": f"{doc['source']}::chunk_{i}",
                    "text": piece,
                }
            )

    return chunks


if __name__ == "__main__":
    # Quick manual test
    sample_docs = [
        {
            "source": "demo.txt",
            "text": "RAG combines retrieval and generation. " * 40,
        }
    ]
    result = chunk_documents(sample_docs, chunk_size=200, chunk_overlap=20)
    print(f"Produced {len(result)} chunks")
    print(result[0])
