"""
data_loader.py
----------------
Handles loading raw documents into plain text, ready for chunking.

Supports:
    - PDF files            (.pdf)
    - Plain text files     (.txt)
    - Hugging Face datasets (e.g. vectara/open_ragbench, squad)

Every loader function returns a list of dicts:
    [{"source": <filename or dataset id>, "text": <raw text>}, ...]

This common shape keeps chunker.py and rag.py decoupled from
where the text actually came from.
"""

import os
from typing import List, Dict


def load_pdf(file_path: str) -> List[Dict]:
    """Extract raw text from a single PDF file."""
    from pypdf import PdfReader

    reader = PdfReader(file_path)
    full_text = ""
    for page in reader.pages:
        page_text = page.extract_text() or ""
        full_text += page_text + "\n"

    return [{"source": os.path.basename(file_path), "text": full_text.strip()}]


def load_txt(file_path: str) -> List[Dict]:
    """Load raw text from a .txt file."""
    with open(file_path, "r", encoding="utf-8") as f:
        text = f.read()
    return [{"source": os.path.basename(file_path), "text": text.strip()}]


def load_folder(folder_path: str) -> List[Dict]:
    """
    Load every supported file (.pdf, .txt) inside a folder.
    Returns a combined list of {"source", "text"} dicts.
    """
    documents = []
    for fname in os.listdir(folder_path):
        fpath = os.path.join(folder_path, fname)
        if fname.lower().endswith(".pdf"):
            documents.extend(load_pdf(fpath))
        elif fname.lower().endswith(".txt"):
            documents.extend(load_txt(fpath))
    return documents


def load_huggingface_dataset(
    dataset_name: str = "squad",
    split: str = "train",
    text_column: str = "context",
    max_docs: int = 200,
) -> List[Dict]:
    """
    Load a Hugging Face dataset and pull out a text column to use as
    our "documents". Deduplicates repeated context passages (common
    in QA datasets like SQuAD where many questions share one context).

    Args:
        dataset_name: HF dataset id, e.g. "squad" or "vectara/open_ragbench"
        split: dataset split to load, e.g. "train" / "validation"
        text_column: which column holds the passage/document text
        max_docs: cap on number of unique documents (keeps things fast for a demo)
    """
    from datasets import load_dataset

    ds = load_dataset(dataset_name, split=split)

    seen = set()
    documents = []
    for i, row in enumerate(ds):
        text = row.get(text_column)
        if not text or text in seen:
            continue
        seen.add(text)
        documents.append({"source": f"{dataset_name}::row_{i}", "text": text.strip()})
        if len(documents) >= max_docs:
            break

    return documents


if __name__ == "__main__":
    # Quick manual test
    docs = load_huggingface_dataset(max_docs=3)
    for d in docs:
        print(d["source"], "->", d["text"][:80], "...")
