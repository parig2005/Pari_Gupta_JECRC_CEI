"""
rag.py
-------
The core RAG chain: takes a user question, retrieves relevant chunks
from the vector store, builds a grounded prompt, and asks a local LLM
(via Ollama) to generate the final answer.

Why Ollama?
    Runs language models locally (no API key, no cost), which pairs
    well with a fully local/offline RAG pipeline. Swap `model_name`
    for any model you've pulled with `ollama pull <model>`.
"""

from typing import List
from langchain_ollama import OllamaLLM
from langchain_core.documents import Document
from langchain_core.prompts import ChatPromptTemplate

DEFAULT_LLM_MODEL = "llama3"

PROMPT_TEMPLATE = """You are a helpful assistant answering questions using ONLY the context provided below.
If the answer isn't contained in the context, say "I don't have enough information in the document to answer that."
Do not use outside knowledge.

Context:
{context}

Question: {question}

Answer:"""


def format_context(chunks: List[Document]) -> str:
    """Join retrieved chunks into a single context string for the prompt."""
    return "\n\n---\n\n".join(chunk.page_content for chunk in chunks)


def build_prompt(question: str, chunks: List[Document]) -> str:
    """Fill the RAG prompt template with retrieved context + the question."""
    context = format_context(chunks)
    prompt = ChatPromptTemplate.from_template(PROMPT_TEMPLATE)
    return prompt.format(context=context, question=question)


def generate_answer(
    question: str,
    retrieved_chunks: List[Document],
    model_name: str = DEFAULT_LLM_MODEL,
) -> str:
    """
    Generate a grounded answer to `question` using `retrieved_chunks` as context.

    Requires Ollama running locally with the target model pulled, e.g.:
        ollama pull llama3
    """
    llm = OllamaLLM(model=model_name)
    prompt = build_prompt(question, retrieved_chunks)
    response = llm.invoke(prompt)
    return response


def answer_question(vector_store, question: str, k: int = 4, model_name: str = DEFAULT_LLM_MODEL) -> dict:
    """
    End-to-end convenience function: retrieve + generate in one call.

    Returns:
        {
            "question": ...,
            "answer": ...,
            "sources": [list of source chunk_ids used as context]
        }
    """
    from src.vector_store import retrieve_relevant_chunks

    chunks = retrieve_relevant_chunks(vector_store, question, k=k)
    answer = generate_answer(question, chunks, model_name=model_name)

    return {
        "question": question,
        "answer": answer,
        "sources": [c.metadata.get("chunk_id", "unknown") for c in chunks],
    }
