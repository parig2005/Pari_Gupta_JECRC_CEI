"""
vector_store.py
-----------------
Embedding creation + vector database (Chroma) handling.

Embedding model: sentence-transformers/all-MiniLM-L6-v2 (384-dim)
    - Small, fast, runs locally on CPU, no API key required.

Vector DB: Chroma
    - Lightweight, file-based (persists to disk), no server needed --
      perfect for a beginner / local RAG project.
"""

from typing import List, Dict
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma
from langchain_core.documents import Document

EMBEDDING_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
DEFAULT_PERSIST_DIR = "chroma_db"
DEFAULT_COLLECTION_NAME = "rag_docs"


def get_embedding_model(model_name: str = EMBEDDING_MODEL_NAME) -> HuggingFaceEmbeddings:
    """Load the embedding model used to convert text into vectors."""
    return HuggingFaceEmbeddings(model_name=model_name)


def build_vector_store(
    chunks: List[Dict],
    persist_directory: str = DEFAULT_PERSIST_DIR,
    collection_name: str = DEFAULT_COLLECTION_NAME,
    embedding_model: HuggingFaceEmbeddings = None,
) -> Chroma:
    """
    Embed a list of chunks and store them in a persistent Chroma collection.

    Args:
        chunks: output of chunker.py chunk_documents()
        persist_directory: folder where Chroma will save its files on disk
        collection_name: name of the Chroma collection
        embedding_model: reuse an already-loaded embedding model if provided

    Returns:
        A Chroma vector store instance, ready for similarity search.
    """
    if embedding_model is None:
        embedding_model = get_embedding_model()

    documents = [
        Document(
            page_content=chunk["text"],
            metadata={"source": chunk["source"], "chunk_id": chunk["chunk_id"]},
        )
        for chunk in chunks
    ]

    vector_store = Chroma.from_documents(
        documents=documents,
        embedding=embedding_model,
        collection_name=collection_name,
        persist_directory=persist_directory,
    )

    return vector_store


def load_vector_store(
    persist_directory: str = DEFAULT_PERSIST_DIR,
    collection_name: str = DEFAULT_COLLECTION_NAME,
    embedding_model: HuggingFaceEmbeddings = None,
) -> Chroma:
    """Reload an existing persisted Chroma collection (skip re-embedding)."""
    if embedding_model is None:
        embedding_model = get_embedding_model()

    return Chroma(
        collection_name=collection_name,
        embedding_function=embedding_model,
        persist_directory=persist_directory,
    )


def retrieve_relevant_chunks(vector_store: Chroma, query: str, k: int = 4) -> List[Document]:
    """Return the top-k most relevant chunks for a user query."""
    return vector_store.similarity_search(query, k=k)


if __name__ == "__main__":
    demo_chunks = [
        {"source": "demo.txt", "chunk_id": "demo::0", "text": "RAG retrieves relevant text before generating an answer."},
        {"source": "demo.txt", "chunk_id": "demo::1", "text": "Vector databases store embeddings for fast similarity search."},
    ]
    vs = build_vector_store(demo_chunks, persist_directory="demo_chroma_db")
    results = retrieve_relevant_chunks(vs, "What does RAG do?", k=1)
    print(results[0].page_content)
